package br.rhuan.appfirebase2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

import org.w3c.dom.Text;

import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    private Button logout;
    private TextView txtResultadoCalculo;

    private EditText edtParede, edtJanela, edtPorta, edtTinta, edtDemaos;
    private Button btCalcular;
    DecimalFormat d = new DecimalFormat("0.00");
    int demaos;
    String resultado;
    double parede, janela, porta, tinta, areapintada, quantidadeGaloes, quantidadeTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inicializarComponentes();
        mAuth = FirebaseAuth.getInstance();
        logout = findViewById(R.id.btSair);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                Intent intent = new Intent(MainActivity.this, loginFirebase2.class);
                startActivity(intent);
                finish();
            }
        });
        btCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edtParede.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this,"Informe os m2 da Parede",Toast.LENGTH_LONG).show();

                }else if (edtTinta.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this,"Informe o Rendimento da Tinta por litro (em m²)",Toast.LENGTH_LONG).show();

                }else if(edtDemaos.getText().toString().equals("")) {
                    Toast.makeText(MainActivity.this,"Informe o número de Demãos",Toast.LENGTH_LONG).show();

                }else{
                    parede = Double.parseDouble(edtParede.getText().toString());
                    areapintada = parede;
                    if (!edtJanela.getText().toString().equals("")) {
                        janela = Double.parseDouble(edtJanela.getText().toString());
                        areapintada = areapintada - janela;
                    }
                    if (!edtPorta.getText().toString().equals("")) {
                        porta = Double.parseDouble(edtJanela.getText().toString());
                        areapintada = areapintada - porta;
                    }
                    tinta = Double.parseDouble(edtTinta.getText().toString());
                    demaos = Integer.parseInt(edtDemaos.getText().toString());
                    quantidadeGaloes = areapintada / tinta;
                    quantidadeTotal = quantidadeGaloes * demaos;
                    resultado = " A Quantidade de Litros a ser Utilizada será de " + d.format(quantidadeTotal);
                    txtResultadoCalculo.setText(resultado);
                }


            }
        });
    }

    private void inicializarComponentes() {
        edtParede = (EditText) findViewById(R.id.edtParede);
        edtJanela = (EditText) findViewById(R.id.edtJanela);
        edtPorta = (EditText) findViewById(R.id.edtPorta);
        edtTinta = (EditText) findViewById(R.id.edtTinta);
        edtDemaos = (EditText) findViewById(R.id.edtDemaos);
        btCalcular = (Button) findViewById(R.id.btCalcular);
        txtResultadoCalculo = (TextView) findViewById(R.id.txtResultadoCalculo);

    }
}