package br.rhuan.appfirebase2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class registro extends AppCompatActivity {
    private EditText edtNomeCad, edtSobrenomeCad, edtEmailCad, edtSenhaCad, edtRepetirsenhaCad;
    private CheckBox chMostrarSenhaCad;
    private ProgressBar pbCadastro;
    private FirebaseAuth mAuthCad;
    private Button btCadastrarCad, btLoginCad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        mAuthCad = FirebaseAuth.getInstance();
        inicializarComponentes();
        pbCadastro.setVisibility(View.INVISIBLE);

        chMostrarSenhaCad.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    edtSenhaCad.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    edtRepetirsenhaCad.setTransformationMethod(HideReturnsTransformationMethod.getInstance());

                }else{
                    edtSenhaCad.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    edtRepetirsenhaCad.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });


        btLoginCad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(registro.this, loginFirebase2.class);
                startActivity(intent);

            }


        });
        btCadastrarCad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nomeCad = edtNomeCad.getText().toString();
                String sobrenomeCad = edtSobrenomeCad.getText().toString();
                String emailCad = edtEmailCad.getText().toString();
                String senhaCad = edtSenhaCad.getText().toString();
                String repetirSenhaCad = edtRepetirsenhaCad.getText().toString();

                if(!TextUtils.isEmpty(nomeCad) || !TextUtils.isEmpty(sobrenomeCad) || !TextUtils.isEmpty(emailCad) ||
                        !TextUtils.isEmpty(senhaCad) || !TextUtils.isEmpty(repetirSenhaCad)){
                    if(senhaCad.equals(repetirSenhaCad)){
                        pbCadastro.setVisibility(View.VISIBLE);

                        mAuthCad.createUserWithEmailAndPassword(emailCad,senhaCad).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if(task.isSuccessful()){
                                    abrirTelaPrincipal();
                                }else{
                                    String error = task.getException().getMessage();
                                    Toast.makeText(registro.this,""+error,Toast.LENGTH_SHORT).show();
                                }
                                pbCadastro.setVisibility(View.INVISIBLE);
                            }
                        });
                    }else{
                        Toast.makeText(registro.this,"A senha deve ser a mesma em ambos os campos!",Toast.LENGTH_SHORT).show();
                    }

                }



            }
        });
    }

    private void abrirTelaPrincipal() {
        Intent intent = new Intent(registro.this, loginFirebase2.class);
        startActivity(intent);
        finish();
    }


    private void inicializarComponentes() {
        edtNomeCad = (EditText) findViewById(R.id.edtNomeCadastro);
        edtSobrenomeCad = (EditText) findViewById(R.id.edtSobrenomeCadastro);
        edtEmailCad = (EditText) findViewById(R.id.edtEmailCadastro);
        edtSenhaCad = (EditText) findViewById(R.id.edtSenhaCadastro);
        edtRepetirsenhaCad = (EditText) findViewById(R.id.edtRepitaSenhaCadastro);
        chMostrarSenhaCad = (CheckBox) findViewById(R.id.chMostrarSenhaCadastro);
        pbCadastro = (ProgressBar)  findViewById(R.id.pbCadastro);
        btLoginCad = (Button) findViewById(R.id.btLoginCadastro);
        btCadastrarCad = (Button) findViewById(R.id.btCadastrarCadastro);

    }
}