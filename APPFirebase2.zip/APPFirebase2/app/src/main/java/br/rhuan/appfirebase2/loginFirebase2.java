package br.rhuan.appfirebase2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class loginFirebase2 extends AppCompatActivity {
    private EditText edtEmail, edtSenha;
    private CheckBox chMostrarSenha;
    private Button btLogar, btCadastrar;
    private ProgressBar pbBar;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_firebase2);
        mAuth = FirebaseAuth.getInstance();
        inicializarComponentes();
        pbBar.setVisibility(View.INVISIBLE);

        chMostrarSenha.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    edtSenha.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }else{
                    edtSenha.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
            }
        });

        btLogar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String loginEmail = edtEmail.getText().toString();
                String loginSenha = edtSenha.getText().toString();
                if(!TextUtils.isEmpty(loginEmail) || !TextUtils.isEmpty(loginSenha)){
                    pbBar.setVisibility(View.VISIBLE);
                    mAuth.signInWithEmailAndPassword(loginEmail,loginSenha).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){
                                abrirTelaPrincipal();
                            }else{
                                String error = task.getException().getMessage();
                                Toast.makeText(loginFirebase2.this,""+error,Toast.LENGTH_SHORT).show();
                                pbBar.setVisibility(View.INVISIBLE);
                            }
                        }

                        private void abrirTelaPrincipal() {
                            Intent intent = new Intent(loginFirebase2.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    });


                }




            }
        });
        btCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(loginFirebase2.this, registro.class);
                startActivity(intent);
                finish();
            }
        });
    }




    private void inicializarComponentes() {
        edtEmail = (EditText) findViewById(R.id.edtEmailLogin);
        edtSenha = (EditText) findViewById(R.id.edtSenhaLogin);
        chMostrarSenha = (CheckBox) findViewById(R.id.chMostrarSenhaLogin);
        btLogar = (Button) findViewById(R.id.btLogarLogin);
        btCadastrar = (Button) findViewById(R.id.btCadastrarLogin);
        pbBar = (ProgressBar) findViewById(R.id.pbBarLogin);
    }
}